/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uas;import java.sql.*;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author AZMAY'S
 */
public class koneksi {
    Connection koneksii;
     public  Connection koneksiDB(){

 try { 
     Class.forName("com.mysql.jdbc.Driver");
     koneksii=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/operator","root","");
    System.out.println("koneksi berhasil");
    return koneksii;
 }catch(Exception e) {
   System.err.print("koneksi gagal");
 //JOptionPane.showMessageDialog(null, e);
     return null;
    }
 }  

    Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
